﻿
//--Create database
CREATE DATABASE ST10446806;

//--Use the database
USE ST10446806;

//--Create table for subjects
CREATE TABLE Subjects (
    SubjectID INT PRIMARY KEY AUTO_INCREMENT,
    SubjectName VARCHAR(100) NOT NULL
);

--Create table for students
CREATE TABLE Students (
    StudentID INT PRIMARY KEY AUTO_INCREMENT,
    StudentNumber VARCHAR(20) UNIQUE NOT NULL,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    DateOfBirth DATE,
    Email VARCHAR(100)
);

--Create table for grades (4 assessments)
CREATE TABLE Grades (
    GradeID INT PRIMARY KEY AUTO_INCREMENT,
    StudentID INT NOT NULL,
    SubjectID INT NOT NULL,
    Assess1 DECIMAL(5,2),
    Assess2 DECIMAL(5,2),
    Assess3 DECIMAL(5,2),
    Assess4 DECIMAL(5,2),
    FOREIGN KEY (StudentID) REFERENCES Students(StudentID),
    FOREIGN KEY (SubjectID) REFERENCES Subjects(SubjectID)
);

--Insert sample subjects
INSERT INTO Subjects (SubjectName)
VALUES ('Mathematics'), ('English'), ('Science');

--Insert sample students
INSERT INTO Students (StudentNumber, FirstName, LastName, DateOfBirth, Email)
VALUES
('STU001', 'Alice', 'Smith', '2005-04-12', 'alice.smith@example.com'),
('STU002', 'Bob', 'Johnson', '2004-11-23', 'bob.johnson@example.com');

--Insert sample grades
INSERT INTO Grades (StudentID, SubjectID, Assess1, Assess2, Assess3, Assess4)
VALUES
(1, 1, 83.00, 78.50, 92.00, 88.00),
(1, 2, 70.00, 85.00, 65.00, 93.51),
(2, 1, 54.00, 85.50, 74.00, 68.79),
(2, 3, 78.00, 80.00, 87.50, 87.19);
